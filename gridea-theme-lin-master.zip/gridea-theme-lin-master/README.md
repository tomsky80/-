# Gridea的一款二次元的风格主题

演示地址：[https://apa70.com](https://apa70.com)

前端使用了一款安卓风格的框架 [MDUI](https://www.mdui.org/)

左下角看板娘的地址[https://www.wikimoe.com/?post=76](https://www.wikimoe.com/?post=76)

